<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="UTF-8">
  <title>Your Cart</title>
  <link rel="stylesheet" href="css/style.css">
</head>
<body>
  <header>
    <h1>Your Shopping Cart</h1>
    <nav>
      <a href="index.php">Home</a>
      <a href="checkout.php">Checkout</a>
    </nav>
  </header>

  <div class="cart-items"></div>
  <h3>Total: <span class="cart-total">0</span></h3>

  <script src="js/script.js"></script>
</body>
</html>

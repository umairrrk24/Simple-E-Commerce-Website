document.addEventListener("DOMContentLoaded", function () {
  const addToCartButtons = document.querySelectorAll(".add-to-cart");
  const cartCount = document.querySelector(".cart-count");
  let cart = JSON.parse(localStorage.getItem("cart")) || [];

  function updateCartCount() {
    if (cartCount) cartCount.textContent = cart.length;
  }
  updateCartCount();

  // Add to Cart
  addToCartButtons.forEach(btn => {
    btn.addEventListener("click", function () {
      const product = { name: this.dataset.name, price: this.dataset.price };
      cart.push(product);
      localStorage.setItem("cart", JSON.stringify(cart));
      updateCartCount();
      showAlert(`${product.name} added to cart!`);
    });
  });

  // Show Alert
  function showAlert(message) {
    const alertBox = document.createElement("div");
    alertBox.className = "alert-box";
    alertBox.textContent = message;
    document.body.appendChild(alertBox);
    setTimeout(() => alertBox.classList.add("show"), 50);
    setTimeout(() => {
      alertBox.classList.remove("show");
      setTimeout(() => alertBox.remove(), 400);
    }, 2000);
  }

  // Display Cart Items
  const cartContainer = document.querySelector(".cart-items");
  if (cartContainer) {
    if (cart.length === 0) {
      cartContainer.innerHTML = "<p>Your cart is empty.</p>";
    } else {
      let html = "";
      let total = 0;
      cart.forEach((item, i) => {
        total += parseFloat(item.price);
        html += `
          <div class="cart-item">
            <span>${item.name}</span>
            <span>PKR ${item.price}</span>
            <button class="remove" data-index="${i}">x</button>
          </div>`;
      });
      cartContainer.innerHTML = html;
      document.querySelector(".cart-total").textContent = `PKR ${total}`;

      // Remove item
      document.querySelectorAll(".remove").forEach(btn => {
        btn.addEventListener("click", function () {
          const i = this.dataset.index;
          cart.splice(i, 1);
          localStorage.setItem("cart", JSON.stringify(cart));
          location.reload();
        });
      });
    }
  }

  // Checkout form
  const checkoutForm = document.getElementById("checkout-form");
  if (checkoutForm) {
    checkoutForm.addEventListener("submit", function (e) {
      e.preventDefault();
      localStorage.removeItem("cart");
      window.location.href = "success.html";
    });
  }
});

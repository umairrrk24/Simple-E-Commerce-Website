<?php
include 'db.php';

if (isset($_POST['place_order'])) {
    $name = $_POST['name'];
    $address = $_POST['address'];
    $phone = $_POST['phone'];
    $total = $_POST['total'];

    $query = "INSERT INTO orders (name, address, phone, total) VALUES ('$name', '$address', '$phone', '$total')";
    $result = mysqli_query($conn, $query);

    if ($result) {
        echo "<h2>✅ Order Placed Successfully!</h2>";
        echo "<p>Thank you, <b>$name</b>. Your order total is PKR $total.</p>";
    } else {
        echo "Error: " . mysqli_error($conn);
    }
}
?>

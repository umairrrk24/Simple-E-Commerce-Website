<?php include 'db.php'; ?>
<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="UTF-8">
  <title>Checkout</title>
  <link rel="stylesheet" href="css/style.css">
</head>
<body>
  <header>
    <h1>Checkout</h1>
  </header>

  <form action="success.php" method="POST" class="checkout-form">
    <input type="text" name="name" placeholder="Full Name" required>
    <input type="text" name="address" placeholder="Address" required>
    <input type="text" name="phone" placeholder="Phone" required>
    <input type="number" name="total" id="orderTotal" placeholder="Total Amount" required readonly>
    <button type="submit" name="place_order">Place Order (Cash on Delivery)</button>
  </form>

  <script>
    // Automatically fill total from cart
    let cart = JSON.parse(localStorage.getItem("cart")) || [];
    let total = cart.reduce((sum, item) => sum + parseFloat(item.price), 0);
    document.getElementById("orderTotal").value = total;
  </script>
</body>
</html>

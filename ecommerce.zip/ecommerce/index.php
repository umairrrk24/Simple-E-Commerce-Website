<?php include 'db.php'; ?>
<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="UTF-8">
  <title>E-commerce Store</title>
  <link rel="stylesheet" href="css/style.css">
</head>
<body>
  <header>
    <h1>Umair's Store</h1>
    <nav>
      <a href="index.php">Home</a>
      <a href="cart.php" class="cart-icon">🛒 <span class="cart-count">0</span></a>
    </nav>
  </header>

  <section class="products">
    <div class="product">
      <img src="images/shirt.jpg" alt="Shirt">
      <h3>Stylish Shirt</h3>
      <p>PKR 1000</p>
      <button class="add-to-cart" data-name="Stylish Shirt" data-price="1000">Add to Cart</button>
    </div>

    <div class="product">
      <img src="images/shoes.jpg" alt="Shoes">
      <h3>Casual Shoes</h3>
      <p>PKR 2000</p>
      <button class="add-to-cart" data-name="Casual Shoes" data-price="2000">Add to Cart</button>
    </div>

    <div class="product">
      <img src="images/watch.jpg" alt="Watch">
      <h3>Smart Watch</h3>
      <p>PKR 2500</p>
      <button class="add-to-cart" data-name="Smart Watch" data-price="2500">Add to Cart</button>
    </div>
  </section>

  <script src="js/script.js"></script>
</body>
</html>

<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="utf-8" />
  <meta name="viewport" content="width=device-width,initial-scale=1" />
  <title>Product — Stylish T-shirt</title>
  <link rel="stylesheet" href="css/style.css">
</head>
<body>
  <header class="site-header small">
    <div class="container">
      <h1 class="logo">My Store</h1>
      <nav class="nav">
        <a href="index.html" class="nav-link">Home</a>
        <a href="cart.html" class="nav-link">Cart</a>
      </nav>
    </div>
  </header>

  <main class="container">
    <section class="product-details animated-in">
      <div class="media-wrap">
        <div class="image-frame">
          <img src="images/tshirt.jpg" alt="Stylish T-shirt">
        </div>
      </div>

      <div class="info">
        <h2>Stylish T-shirt</h2>
        <p class="muted">Comfortable cotton t-shirt. Regular fit. Available in multiple colors.</p>
        <p class="price big">PKR 1000</p>

        <div class="selectors">
          <label>
            Size
            <select>
              <option>S</option>
              <option>M</option>
              <option>L</option>
              <option>XL</option>
            </select>
          </label>
          <label>
            Qty
            <select>
              <option>1</option>
              <option>2</option>
              <option>3</option>
            </select>
          </label>
        </div>

        <div class="product-actions">
          <a class="btn btn-outline" href="index.html">Continue Shopping</a>
          <a class="btn btn-primary btn-add" href="cart.html">Add to Cart</a>
        </div>

        <div class="product-desc">
          <h4>Product Details</h4>
          <p>Soft breathable fabric. Machine wash friendly. Color may slightly vary in photos.</p>
        </div>
      </div>
    </section>
  </main>

  <footer class="site-footer">
    <div class="container">
      <p>© 2025 My Store</p>
    </div>
  </footer>
</body>
</html>
